<!DOCTYPE html>
<html>
<head>
<body>
<script>
function myFunction() {
  document.getElementById("frm1").submit();
}
</script>
</head>

</body>
</html>